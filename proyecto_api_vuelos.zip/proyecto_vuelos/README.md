# API de inferencia — Atraso de vuelos (FastAPI)

Servicio HTTP que expone un modelo de clasificación que predice si un vuelo
llegará con **15 minutos o más de atraso** (`ARRIVAL_DELAY_15`), usando solo
información conocida **antes de la salida programada**. El modelo se entrena con
scikit-learn y se sirve con FastAPI.

Este repositorio corresponde al **Paso 5 — API con FastAPI** de la tarea.

> **Nota sobre el objetivo.** El `data/README.md` describe la fuente (2015 Flight
> Delays and Cancellations, USDOT). El problema modelado, siguiendo el
> `EDA.ipynb`, es la predicción de **atraso de llegada ≥ 15 min**
> (`ARRIVAL_DELAY_15`) sobre vuelos no cancelados ni desviados — no la predicción
> de cancelación. La API respeta el contrato de datos generado por el EDA.

## Estructura

```
proyecto/
├── app/
│   ├── __init__.py
│   ├── main.py         # aplicación FastAPI (endpoints, lifespan, errores)
│   ├── schemas.py      # modelos Pydantic (contrato de entrada/salida)
│   └── features.py     # contrato de features + canonicalización de códigos
├── model/
│   ├── model.pkl       # pipeline serializado (lo genera train.py)
│   └── metadata.json   # versiones, features y métricas
├── tests/
│   └── test_api.py     # pruebas con TestClient
├── docs/
│   ├── evidencia_local.md
│   └── salida_pytest.txt
├── data/
│   └── README.md       # origen del dataset (no se versionan los CSV)
├── train.py            # entrenamiento + serialización
├── requirements.txt    # dependencias con versiones fijas
├── runtime.txt         # versión de Python
├── Procfile            # comando de arranque (usa $PORT)
└── .gitignore
```

## Contrato de entrada (9 predictores del EDA)

| Campo                     | Tipo   | Restricción / formato                              |
|---------------------------|--------|----------------------------------------------------|
| `AIRLINE`                 | str    | Código IATA de 2 caracteres (ej. `AA`).            |
| `ORIGIN_AIRPORT`          | str    | IATA de 3 letras (`LAX`) o BTS de 5 dígitos.       |
| `DESTINATION_AIRPORT`     | str    | IATA de 3 letras (`JFK`) o BTS de 5 dígitos.       |
| `MONTH`                   | int    | 1–12                                               |
| `DAY`                     | int    | 1–31                                               |
| `DAY_OF_WEEK`             | int    | 1–7 (1 = lunes)                                    |
| `SCHEDULED_DEPARTURE_MIN` | int    | 0–1440 (minutos desde medianoche)                  |
| `SCHEDULED_TIME`          | float  | > 0 (duración programada en minutos)               |
| `DISTANCE`                | float  | > 0 (millas)                                       |

Los códigos se aceptan en forma "plana" (`LAX`, `AA`) y la API los normaliza a la
forma del entrenamiento (`IATA:LAX`), replicando exactamente la limpieza del EDA
para evitar *training–serving skew* (ver `app/features.py`).

## Puesta en marcha (local)

```bash
# 1) Entorno virtual e instalación
python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2) (Opcional) Colocar data/train.csv y data/test.csv generados por EDA.ipynb.
#    Si no están, train.py genera un dataset sintético de respaldo.

# 3) Entrenar el modelo (genera model/model.pkl y model/metadata.json)
python train.py

# 4) Levantar el servicio
uvicorn app.main:app --reload --port 8000
```

Documentación interactiva en <http://localhost:8000/docs>.

## Endpoints

| Método | Ruta             | Descripción                                                   |
|--------|------------------|--------------------------------------------------------------|
| GET    | `/health`        | Estado del servicio y confirmación de modelo cargado.        |
| GET    | `/model-info`    | Metadatos: estimador, target, features, métricas y versión.  |
| POST   | `/predict`       | Predicción para un vuelo (incluye probabilidad).             |
| POST   | `/predict-batch` | Predicción para una lista de vuelos (mismo orden).           |
| GET    | `/docs`          | Swagger UI (automática).                                     |

### Ejemplo: predicción individual

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"AIRLINE":"AA","ORIGIN_AIRPORT":"LAX","DESTINATION_AIRPORT":"JFK",
       "MONTH":7,"DAY":15,"DAY_OF_WEEK":3,"SCHEDULED_DEPARTURE_MIN":1080,
       "SCHEDULED_TIME":320.0,"DISTANCE":2475.0}'
```

Respuesta:

```json
{"prediccion":1,"etiqueta":"atraso >= 15 min","probabilidad":0.5841,
 "probabilidad_atraso":0.5841,"model_version":"1.0.0",
 "timestamp":"2026-09-26T00:58:05Z"}
```

## Decisiones de diseño (lo que evalúa la rúbrica del Paso 5)

- **Carga única del modelo.** El `.pkl` se carga una sola vez al iniciar la app,
  en el evento `lifespan`, y queda en memoria (`ARTIFACTS`); no se recarga por
  petición.
- **Validación con Pydantic.** El esquema `Vuelo` fija tipos, rangos y patrones
  (`AIRLINE` de 2 caracteres, aeropuertos IATA/BTS, `MONTH` 1–12, etc.). Una
  entrada mal formada produce **422** automáticamente.
- **Manejo de errores.**
  - Campos faltantes o valores fuera de contrato → **422** (Pydantic).
  - Fallo interno del modelo → **500** con mensaje controlado (traza al log, no
    al cliente).
  - Modelo no disponible → **503** con instrucción para entrenarlo.
- **Sin skew.** La canonicalización de categóricas se comparte entre `train.py`
  y la API (`app/features.py`). El resto del preprocesamiento (OneHot + escalado)
  vive dentro del pipeline serializado.
- **Respuesta enriquecida.** Predicción, etiqueta legible, probabilidad,
  probabilidad de atraso, versión del modelo y marca de tiempo (UTC).
- **Rutas relativas.** El modelo se referencia con rutas relativas al proyecto.

## Pruebas

```bash
pytest -v
```

Cubren `/health`, `/model-info`, una predicción válida, aceptación de código BTS,
predicción por lote y dos casos de entrada inválida (422). Salida en
`docs/salida_pytest.txt` (**7 passed**).

## Reentrenar con los datos reales

1. Ejecutar `EDA.ipynb` con `flights.csv` para generar `data/train.csv` y
   `data/test.csv`.
2. Ejecutar `python train.py`: detectará esos CSV y entrenará con ellos.
3. Reiniciar el servicio. `/model-info` mostrará las métricas reales.
