# Evidencia de ejecución local

Servicio levantado con:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Log de arranque (el modelo se carga UNA sola vez, en el lifespan):

```
INFO:     Waiting for application startup.
INFO:api-vuelos:Modelo y metadatos cargados correctamente.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://127.0.0.1:8000
```

## 1) GET /health

```json
{"status":"ok","model_loaded":true}
```

## 2) GET /model-info

```json
{"model_type":"LogisticRegression","task":"binary_classification",
 "target":"ARRIVAL_DELAY_15",
 "features":["AIRLINE","ORIGIN_AIRPORT","DESTINATION_AIRPORT","MONTH","DAY",
             "DAY_OF_WEEK","SCHEDULED_DEPARTURE_MIN","SCHEDULED_TIME","DISTANCE"],
 "metrics":{"accuracy":0.584,"f1_macro":0.576,"precision_pos":0.4618,
            "recall_pos":0.5897,"roc_auc":0.6091},
 "sklearn_version":"1.8.0","model_version":"1.0.0"}
```

> Las métricas mostradas corresponden al **dataset sintético de respaldo**. Al
> reentrenar con `data/train.csv` y `data/test.csv` (salidas del EDA sobre los
> datos reales), estas métricas se recalculan y son las que deben reportarse.

## 3) POST /predict — predicción exitosa

Petición (se aceptan códigos IATA "planos"; la API los canoniza a IATA:LAX):

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"AIRLINE":"AA","ORIGIN_AIRPORT":"LAX","DESTINATION_AIRPORT":"JFK",
       "MONTH":7,"DAY":15,"DAY_OF_WEEK":3,"SCHEDULED_DEPARTURE_MIN":1080,
       "SCHEDULED_TIME":320.0,"DISTANCE":2475.0}'
```

Respuesta:

```json
{"prediccion":1,"etiqueta":"atraso >= 15 min","probabilidad":0.5841,
 "probabilidad_atraso":0.5841,"model_version":"1.0.0",
 "timestamp":"2026-09-26T00:58:05Z"}
```

## 4) POST /predict-batch — predicción por lote (mismo orden de entrada)

```json
{"n":2,"predicciones":[
  {"prediccion":1,"etiqueta":"atraso >= 15 min","probabilidad_atraso":0.5841, "...":"..."},
  {"prediccion":0,"etiqueta":"a tiempo","probabilidad_atraso":0.4823, "...":"..."}
]}
```

## 5) POST /predict — entrada inválida => 422

Petición (aerolínea con formato inválido y MONTH fuera de rango):

```json
{"detail":[
  {"type":"string_pattern_mismatch","loc":["body","AIRLINE"],
   "msg":"String should match pattern '^[A-Za-z0-9]{2}$'"},
  {"type":"less_than_equal","loc":["body","MONTH"],
   "msg":"Input should be less than or equal to 12"}
]}
```

## 6) GET /docs

`HTTP 200` — Swagger UI navegable.

> Pendiente por el equipo: agregar la captura de pantalla de /docs abierta en el
> navegador (guardarla como `docs/docs_swagger.png`).

## Carga del artefacto en un proceso independiente

```
Carga OK en proceso independiente.
Registro canonizado -> IATA:LAX IATA:JFK
Predicción: 1 | P(atraso)= 0.5841
```
